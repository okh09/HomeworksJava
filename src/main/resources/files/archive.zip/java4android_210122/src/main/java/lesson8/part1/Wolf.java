package lesson8.part1;

public class Wolf extends Animal {


}
