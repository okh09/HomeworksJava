package lesson3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {

    static Scanner in = new Scanner(System.in);


    public static void main(String[] args) {
//        testRandoms();
        testConsoleInput();
    }

    private static void testConsoleInput() {

        int a = getNumFromScanner();
        int b = getNumFromScanner();

//        in.close();

        TestMethods.multuply(a, b);
    }

    private static int getNumFromScanner() {
        while (true) {
            if (in.hasNextInt()) {
                return in.nextInt();
            }
            System.out.println(in.next() + " - это не число!!!");
        }
    }

    private static void testRandoms() {
        int[] data = new int[40];
        Random random = new Random();

        for (int i = 0; i < data.length; i++) {
            data[i] = random.nextInt(); //-2147кк - + 2147кк
            data[i] = random.nextInt(10); // 0 - 9
            data[i] = random.nextInt(8) + 3; // 3 - 10
            data[i] = random.nextInt(3, 11); // 3 - 10
            data[i] = random.nextInt(12) - 5; // -5 -- 6
            data[i] = random.nextInt(-5, 7); // -5 -- 6

            data[i] = (int)(Math.random() * 10) ;
            data[i] = (int)(Math.random() * 8) + 3; // 3 - 10
            data[i] = (int)(Math.random() * 12) - 3; // -5 - +6

        }

        System.out.println(Arrays.toString(data));
    }
}
