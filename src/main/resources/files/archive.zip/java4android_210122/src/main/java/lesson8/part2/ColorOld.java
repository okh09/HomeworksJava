package lesson8.part2;

public class ColorOld {
    public static final String BLACK = "black";
    public static final String WHITE = "white";
    public static final String GREY = "grey";
}
