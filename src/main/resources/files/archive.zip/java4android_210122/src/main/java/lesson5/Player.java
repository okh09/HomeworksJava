package lesson5;

import java.util.Objects;

public class Player {

    private static int playersCount = 0;

    private String nickname;
    private int points;
    private int level;
    private int money;

    public Player(String nickname, int level, int points, int money) {
        this.nickname = nickname.toUpperCase();
        this.points = points;
        this.level = level;
        this.money = Math.abs(money);

        playersCount++;
    }

    public Player(String nickname) {
        this(nickname, 1, 0, 100);
    }

    public static int getPlayersCount() {
        return playersCount;
    }

    public static void setPlayersCount(int playersCount) {
        Player.playersCount = playersCount;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void printInfo() {
        System.out.println(this/*.toString()*/);
    }

    public String toString() {
        return String.format("У игрока %s(%d лвл) %d монет и %d очков",nickname, level, money,
                points);
    }

    public String getNickname() {
        return nickname;
    }

    public int getPoints() {
//        System.out.println("Кто-то обратился к данным очков у пользователя " + nickname);
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        if (money < 0 || money > Short.MAX_VALUE) {
            System.out.println("ОШИБКА! Неверное кол-во монет: " + money);
        } else {
            this.money = money;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Player player = (Player) o;
        return nickname.equals((player.nickname));
    }

    @Override
    public int hashCode() {
        return Objects.hash(nickname);
    }
}
