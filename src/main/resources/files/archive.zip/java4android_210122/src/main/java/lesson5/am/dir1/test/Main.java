package lesson5.am.dir1.test;

import lesson5.am.dir1.CatNew;

public class Main {
    public static void main(String[] args) {
    }
}
