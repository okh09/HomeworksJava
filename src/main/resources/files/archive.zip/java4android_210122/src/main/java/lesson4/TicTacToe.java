package lesson4;

import java.util.Random;
import java.util.Scanner;

public class TicTacToe {
    private  final int SIZE = 3;

    private  final char DOT_EMPTY = '•';
    private  final char DOT_HUMAN = 'X';
    private  final char DOT_AI = 'O';

    private  char[][] MAP ;
    private  final Scanner in = new Scanner(System.in);
    private  final Random random = new Random();

    private  final String SPACE_MAP = " ";
    private  final String HEADER_FIRST_SYMBOL = "♥";

    private  int turnsCount;

    public  void turnGame() {
        do {
            System.out.println("\n\nИГРА НАЧИНАЕТСЯ");
            init();
            printMap();
            playGame();
        } while (isContinueGame());
        endGame();
    }

    private  void init() {
        turnsCount = 0;

        MAP = new char[SIZE][SIZE];

        initMap();
    }

    private  void initMap() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                MAP[i][j] = DOT_EMPTY;
            }
        }
    }

    private  void printMap() {
        printMapHeader();
        printMapBody();
    }

    private  void printMapHeader() {
        System.out.print(HEADER_FIRST_SYMBOL + SPACE_MAP);
        for (int i = 0; i < SIZE; i++) {
            printMapNumber(i);
        }
        System.out.println();
    }

    private  void printMapNumber(int i) {
        System.out.print(i + 1 + SPACE_MAP);
    }

    private  void printMapBody() {
        for (int i = 0; i < SIZE; i++) {
            printMapNumber(i);
            for (int j = 0; j < SIZE; j++) {
                System.out.print(MAP[i][j] + SPACE_MAP);
            }
            System.out.println();
        }
    }

    private  void playGame() {
        while (true) {
            humanTurn();
            printMap();
            if (checkEnd(DOT_HUMAN)) {
                break;
            }

            aiTurn();
            printMap();
            if (checkEnd(DOT_AI)) {
                break;
            }
        }
    }

    private  void humanTurn() {
        System.out.println("ХОД ЧЕЛОВЕКА");

        int rowNumber;
        int columnNumber;

        while (true) {
            rowNumber = getValidNumberFromUser() - 1;
            columnNumber = getValidNumberFromUser() - 1;

            if (isCellFree(rowNumber, columnNumber)) {
                break;
            }
        }


        MAP[rowNumber][columnNumber] = DOT_HUMAN;
        turnsCount++;
    }

    private  int getValidNumberFromUser() {
        while (true) {
            System.out.print("Введите координату(1-" + SIZE + "): ");
            if (in.hasNextInt()) {
                int n = in.nextInt();
                if (isNumberValid(n)) {
                    return n;
                }
                System.out.println("\nПроверьте значение координаты. Должно быть от 1 до " + SIZE);
            } else {
                in.next();
                System.out.println("\nВвод допускает лишь целые числа");
            }
        }
    }

    private  boolean isNumberValid(int n) {
        return n >= 1 && n <= SIZE;
    }

    private  boolean isCellFree(int rowNumber, int columnNumber) {
        return MAP[rowNumber][columnNumber] == DOT_EMPTY;
    }

    private  boolean checkEnd(char symbol) {
        if (checkWin(symbol)) {
            if (symbol == DOT_HUMAN) {
                System.out.println("\nУРАААААААААААААААА!! Вы победили!");
            } else {
                System.out.println("\nВосстание близко... ИИ победил...");
            }
            return true;
        }

        if (checkDraw()) {
            System.out.println("Ничья!");
            return true;
        }
        return false;
    }

    private  boolean checkDraw() {
        /*for (char[] chars : MAP) {
            for (char symbol : chars) {
               if (symbol == DOT_EMPTY) {
                   return false;
               }
            }
        }
        return true;*/

        return turnsCount >= SIZE * SIZE;

    }

    private  boolean checkWin(char symbol) {
        if (MAP[0][0] == symbol && MAP[0][1] == symbol && MAP[0][2] == symbol) {
            return true;
        }
        if (MAP[1][0] == symbol && MAP[1][1] == symbol && MAP[1][2] == symbol) {
            return true;
        }
        if (MAP[2][0] == symbol && MAP[2][1] == symbol && MAP[2][2] == symbol) {
            return true;
        }

        if (MAP[0][0] == symbol && MAP[1][0] == symbol && MAP[2][0] == symbol) {
            return true;
        }
        if (MAP[0][1] == symbol && MAP[1][1] == symbol && MAP[2][1] == symbol) {
            return true;
        }
        if (MAP[0][2] == symbol && MAP[1][2] == symbol && MAP[2][2] == symbol) {
            return true;
        }

        if (MAP[0][0] == symbol && MAP[1][1] == symbol && MAP[2][2] == symbol) {
            return true;
        }
        if (MAP[0][2] == symbol && MAP[1][1] == symbol && MAP[2][0] == symbol) {
            return true;
        }

        return false;
    }

    private  void aiTurn() {
        System.out.println("ХОД ЧЕЛОВЕКА");

        int rowNumber;
        int columnNumber;

        do {
            rowNumber = random.nextInt(SIZE); //0 - S -1;
            columnNumber = random.nextInt(SIZE);

        } while (!isCellFree(rowNumber, columnNumber));


        MAP[rowNumber][columnNumber] = DOT_AI;
        turnsCount++;
    }

    private  boolean isContinueGame() {
        System.out.println("Хотите продолжить? y\\n");
        return switch (in.next()) {
            case "y", "yes", "+", "да", "конечно" -> true;
            default -> false;
        };
    }

    private  void endGame() {
        in.close();
        System.out.println("Ты заходи, если что");
    }
}
