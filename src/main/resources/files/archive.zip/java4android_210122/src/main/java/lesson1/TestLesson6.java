package lesson1;

import lesson6.Player;

public class TestLesson6 extends Player {

    public TestLesson6(String nickname, int points, String russianProfessionTitle) {
        super(nickname, points, russianProfessionTitle);
    }

    @Override
    public void action() {
        nickname = "df";

    }
}
