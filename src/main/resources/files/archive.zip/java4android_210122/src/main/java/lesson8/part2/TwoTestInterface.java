package lesson8.part2;

public interface TwoTestInterface {
    void action(int a);
}
