package lesson6;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        Player knight1 = new Knight("Роман", 1000);
        Player knight2 = new Knight("Андрей", 2000 );
        Player wizard = new Wizard("Александр", 900);
        Player bard = new Bard("Лютик", 10);
//        Player player = new Player();
//        bard.sing();

        Player[] players = {knight1, bard, knight2, wizard};

        for (Player player : players) {
/*            if (player instanceof Bard) {
                Bard trueBard = (Bard) player;
                trueBard.sing();
            }*/

            if (player instanceof Bard trueBard) {
                trueBard.sing();
            }
            player.printInfo();
            test(player);
            System.out.println("------------\n");
        }
    }

    public static void test(Player player) {
        System.out.println("ИГРОК ГОТОВИТСЯ ЧТО-ТО СОВЕРШИТЬ....");
        player.action();
    }

    public static void test(Map map) {
        map.size();
    }
}
