package lesson8.part1;

public class Dog extends Animal implements Runner, Swimming {


    @Override
    public void run() {

    }

    @Override
    public void action() {

    }

    @Override
    public void swim() {

    }
}
