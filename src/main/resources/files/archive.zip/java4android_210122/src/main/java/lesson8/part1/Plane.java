package lesson8.part1;

public class Plane implements Flying{

    @Override
    public void fly() {

    }

    @Override
    public void action() {

    }
}
