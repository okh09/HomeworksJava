package lesson6;

public class Wizard extends Player {

    public Wizard(String nickname, int points) {
        super(nickname, points, "Чародей");
    }

    @Override
    public void action() {
        System.out.println(getNickname() + " кастует заклинание");
    }
}
