package lesson2;

public class WhileTest {

    static int orangesCount = 10;

    public static void main(String[] args) {

        int appleCount = 15;

        while (appleCount > 0) {
            appleCount--;
            System.out.println(appleCount);
        }

        while (isOrangeCountPositive()) {
            eatOrange();
            printOrangeCount();
        }

        System.out.println("======================");

        do {
            eatOrange();
            printOrangeCount();
        } while (isOrangeCountPositive());
    }

    private static boolean isOrangeCountPositive() {
        return orangesCount > 0;
    }

    private static void eatOrange() {
        orangesCount--;
    }

    private static void printOrangeCount() {
        System.out.println("Количество апeльсинов: " + orangesCount );
    }
}
