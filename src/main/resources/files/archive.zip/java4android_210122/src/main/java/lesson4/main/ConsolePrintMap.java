package lesson4.main;

class ConsolePrintMap {
    private final String EMPTY = " ";
    private final String HEADER_FIRST_SYMBOL = "♥";

    final char DOT_EMPTY = '•';
    final char DOT_PLAYER_1 = 'X';
    final char DOT_PLAYER_2 = 'O';

    String outputPattern;
    
    private int mapSize;

    protected void printMap() {
        outputPattern = (TicTacToe.size < 10) ? "%s%s" : "%2s%s";


        printHeaderMap();

        printBodyMap();
    }

    private void printHeaderMap() {
        System.out.printf(outputPattern, HEADER_FIRST_SYMBOL, EMPTY);
        for (int i = 0; i < mapSize; i++) {
            printMapNumber(i);
        }
        System.out.println();
    }

    private void printBodyMap() {
        for (int i = 0; i < mapSize; i++) {
            printMapNumber(i);
            for (int j = 0; j < mapSize; j++) {
                System.out.printf(outputPattern, getPlayerSymbol(TicTacToe.map[i][j]), EMPTY);
            }

            System.out.println();
        }
    }

    private char getPlayerSymbol(int dot) {
        return switch (dot) {
            case 0 -> DOT_EMPTY;
            case 1 -> DOT_PLAYER_1;
            case 2 -> DOT_PLAYER_2;
            default -> '?';
        };
    }

    private void printMapNumber(int i) {
        System.out.printf(outputPattern, i + 1, EMPTY);
    }

    public void setMapSize(int mapSize) {
        this.mapSize = mapSize;
    }
}
