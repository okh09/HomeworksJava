package lesson4.main;

import java.util.Random;
import java.util.Scanner;

public class TicTacToe {

    protected static int size;
    protected static int[][] map;

    private final int EMPTY_DOT = 0;
    private final int AI_PLAYER = 1;
    private final int HUMAN_PLAYER = 2;

    private final Scanner in = new Scanner(System.in);
    private final Random random = new Random();
    private final ConsolePrintMap printer = new ConsolePrintMap();
    private final WinChecker winChecker = new WinChecker();

    private int turnsCount = 0;


    public static void main(String[] args) {

        new TicTacToe().turnGame();
    }

    public void turnGame() {
        do {
            initGame();

            printer.printMap();

            playGame();

        } while (isContinueGame());

        endGame();
    }

    private void initGame() {

        size = getMapSize();
        map = new int[size][size];

        printer.setMapSize(size);
        winChecker.setWinSize();
        winChecker.setMaxIndex(size - 1);
    }

    private int getMapSize() {
        int size;
        do {
            printSizeInfo();
            System.out.println("Введите размер поля. Минимальный: 3. Максимальный: 30");
            System.out.print("Ввод: ");
            if (in.hasNextInt()) {
                size = in.nextInt();
                if (size >= 3 && size <= 30) {
                    return size;
                }
            }
            System.out.println("!Введите корректный размер");
        } while (true);
    }

    private void printSizeInfo() {
        System.out.println("""                       
                           В зависимости от размера поля у Вас будет различная длина победной серии фишек.
                           size: 3-6 => 3
                           size: 7-10 => 4
                           size: 11+ => 5
                           """);
    }


    private void playGame() {

        do {
            humanTurn();
            printer.printMap();
            if (checkEnd(HUMAN_PLAYER)) {
                break;
            }

            aiTurn();
            printer.printMap();
            if (checkEnd(AI_PLAYER)) {
                break;
            }
        } while (true);

    }

    private void humanTurn() {
        int rowNumber;
        int colNumber;
        boolean isInputValid;

        System.out.println("\nХод человека! Введите номера строки и столбца");
        do {
            rowNumber = -1;
            colNumber = -1;
            isInputValid = true;

            System.out.print("Строка: ");
            if (in.hasNextInt()) {
                rowNumber = in.nextInt() - 1;
            } else {
                processingIncorrectInput();
                isInputValid = false;
                continue;
            }

            System.out.print("Столбец: ");
            if (in.hasNextInt()) {
                colNumber = in.nextInt() - 1;
            } else {
                processingIncorrectInput();
                isInputValid = false;
            }
        } while (!(isInputValid && isHumanTurnValid(rowNumber, colNumber)));

        map[rowNumber][colNumber] = HUMAN_PLAYER;

        winChecker.setLastTurnRow(rowNumber);
        winChecker.setLastTurnColumn(colNumber);


        turnsCount++;
    }

    private void processingIncorrectInput() {
        System.out.println("Ошибка ввода! Введите число в диапазоне игрового поля");
        in.next();
    }

    private boolean isHumanTurnValid(int rowNumber, int colNumber) {
        if (!isNumberValid(rowNumber, colNumber)) {
            System.out.println("\nПроверьте значение строки и столбца");
            return false;
        }
        if (!isCellFree(rowNumber, colNumber)) {
            System.out.println("\nВы выбрали занятую ячейку");
            return false;
        }
        return true;
    }

    private boolean isNumberValid(int rowNumber, int colNumber) {
        return rowNumber < size && rowNumber >= 0 && colNumber < size && colNumber >= 0;
    }

    private boolean isCellFree(int rowNumber, int colNumber) {
        return map[rowNumber][colNumber] == EMPTY_DOT;
    }


    private boolean checkEnd(int player) {

        if (winChecker.checkWin(player)) {
            if (player == HUMAN_PLAYER) {
                System.out.println("Ура! Вы победили!");
            } else {
                System.out.println("Восстание близко... ИИ победил");
            }
            return true;
        }
        if (isMapFull()) {
            System.out.println("Ничья!");
            return true;
        }

        return false;
    }

    private boolean isMapFull() {
        return turnsCount == size * size;
    }

    private void aiTurn() {
        int rowNumber;
        int colNumber;

        System.out.println("\nХод компуктера");
        do {
            rowNumber = random.nextInt(size);
            colNumber = random.nextInt(size);
        } while (!isCellFree(rowNumber, colNumber));
        map[rowNumber][colNumber] = AI_PLAYER;

        winChecker.setLastTurnRow(rowNumber);
        winChecker.setLastTurnColumn(colNumber);

        turnsCount++;
    }

    private boolean isContinueGame() {
        System.out.println("Продолжаем? y/n");
        return switch (in.next()) {
            case "y", "yes", "да", "1" -> true;
            default -> false;
        };
    }

    private void endGame() {
        System.out.println("Ты заходи, если что");
        System.exit(0);
    }
}
