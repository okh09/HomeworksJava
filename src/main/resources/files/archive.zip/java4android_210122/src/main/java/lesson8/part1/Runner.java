package lesson8.part1;

public interface Runner {
    /*public final*/ int CONST = 1;
    /*public abstract*/ void run();
    void action();

}
