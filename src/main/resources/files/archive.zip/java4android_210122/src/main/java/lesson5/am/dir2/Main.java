package lesson5.am.dir2;

import lesson5.am.dir1.CatNew;

public class Main  {

    public static void main(String[] args) {
        CatNew catNew = new CatNew();
    }
}
