package lesson5;

public class Main {
    public static void main(String[] args) {

        Player player1 = new Player("Виктор", 80, 1500, 3256);
        Player player2 = new Player("Дмитрий");
        Player player4 = new Player("Тимофей");
        Player player3 = new Player("Влад", 67, 750, 7600);

/*        player1.nickname = "Виктор";
        player2.nickname = "Дмитрий";*/

/*        player1.level = -10;
        player2.level = 8000000;*/

        player1.setMoney(1000000000);
        player3.setMoney(player3.getMoney() + 300);

/*        player1.printInfo();
        player2.printInfo();
        player3.printInfo();*/

//        player1 = null;

        Player[] players = {player1, player2, player3};
        for (int i = 0; i < players.length; i++) {
            Player player = players[i];
            if (player.getPoints() > 300) {
                player.printInfo();
            } else {
                System.out.println("У игрока " + player.getNickname() + " недостаточно очков");
            }
        }

        System.out.println("Общее кол-во игроков: " + Player.getPlayersCount());
    }
}
