package lesson1;

import lesson5.Player;

public class TestLesson5 {
    public static void main(String[] args) {
        Player player = new Player("Лего-человек");
        player.printInfo();
//        player.level = 10;
    }
}
