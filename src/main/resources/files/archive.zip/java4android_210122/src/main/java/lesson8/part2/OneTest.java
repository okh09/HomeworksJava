package lesson8.part2;

public class OneTest extends MainClass{
    @Override
    public void action() {
        System.out.println("One");
    }
}
