package lesson6;

public final class Knight extends Player {

    private String swordTitle;

    public Knight(String nickname, int points, String swordTitle) {
        super(nickname, points, "Рыцарь");
        this.swordTitle = swordTitle;
    }

    public Knight(String nickname, int points) {
        this(nickname, points,  "Меч-кладенец");
    }

    public String getSwordTitle() {
        return swordTitle;
    }

    public void setSwordTitle(String swordTitle) {
        this.swordTitle = swordTitle;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" и имеет оружие %s", swordTitle);
    }

    @Override
    public void action() {
        System.out.println(getRussianProfessionTitle() + " " + "машет оружием " + getSwordTitle());
    }
}
