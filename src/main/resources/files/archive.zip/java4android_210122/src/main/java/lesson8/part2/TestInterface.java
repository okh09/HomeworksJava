package lesson8.part2;

public interface TestInterface {
    void action(int a, int b);
}
