package lesson8.part1;

public interface Participant extends Runner, Swimming, Flying{}
