package lesson8.part2;

public class TwoClass extends MainClass
{
    @Override
    public void action() {
        System.out.println("Two");
    }
}
