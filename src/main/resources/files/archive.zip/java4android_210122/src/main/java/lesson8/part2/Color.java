package lesson8.part2;

public enum Color /*implements Runner*/ {
    BLACK("черный"),
    WHITE("белый"),
    RED("рррыжий"),
    GRAY("Серый");

    private String russianColor;

    Color(String russianColor) {
        this.russianColor = russianColor;
    }

    public String getRussianColor() {
        return russianColor;
    }

}
