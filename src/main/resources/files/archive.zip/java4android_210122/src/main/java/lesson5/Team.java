package lesson5;

public class Team {
    String name;
}
