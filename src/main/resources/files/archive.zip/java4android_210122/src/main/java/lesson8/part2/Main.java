package lesson8.part2;


public class Main {
    public static void main(String[] args) {
//        testEnum();
        testAnonClass();

    }

    private static void testEnum() {

        Cat cat = new Cat();

/*        cat.setColor(ColorOld.GREY);
        cat.setColor("ColorOld.GREY");*/
        cat.setColor(Color.BLACK);

        System.out.println(cat);


    }

    private static void testAnonClass() {
/*        MainClass one = new OneTest();
        MainClass two = new TwoClass();*/

/*        Object o = new Object() {

        };*/

        MainClass one = new MainClass(){
            @Override
            public void action() {
                System.out.println("Three");
            }
        };

        MainClass two = new MainClass(){
            @Override
            public void action() {
                System.out.println("Five");
            }
        };

        one.action();
        two.action();

        TestInterface foo = new TestInterface() {
            @Override
            public void action(int a, int b) {
                System.out.println("a + b = " + (a + b));
            }
        }; //bar baz

        TestInterface bar = (a, b) -> System.out.println(a + " + " + b + " = " + (a + b));

        TwoTestInterface baz = System.out::println;

        foo.action(4, 3);
        bar.action(4, 3);

        AbstrTest abstrTest = new AbstrTest() {
            @Override
            public void action() {
                System.out.println("abstr");
            }
        };


/*        new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                System.out.println(i);
            }
        }).start();*/
    }
}
