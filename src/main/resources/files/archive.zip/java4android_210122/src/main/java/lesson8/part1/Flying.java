package lesson8.part1;

public interface Flying {
    void fly();
    void action();
}
