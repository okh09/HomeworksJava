package lesson5.am.dir1;

public class CatNew {
    public String name;
           String color; //default, package
    protected int age;
    private int weight;

    public static void main(String[] args) {
        CatNew catNew = new CatNew();
    }
}
