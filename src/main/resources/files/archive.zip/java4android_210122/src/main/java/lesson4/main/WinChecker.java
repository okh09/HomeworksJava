package lesson4.main;

class WinChecker {

    protected int winLength;
    private int maxIndex;

    private int lastTurnRow;
    private int lastTurnColumn;

    private int playerSymbol;


    protected void setWinSize() {
        if (TicTacToe.size >= 3 && TicTacToe.size <= 6) {
            winLength = 3;
        } else if (TicTacToe.size >= 7 && TicTacToe.size <= 10) {
            winLength = 4;
        } else {
            winLength = 5;
        }
    }

    protected boolean checkWin(int playerSymbol) {
        this.playerSymbol = playerSymbol;
        return checkRow() || checkColumn() || checkMainDiagonal() || checkSideDiagonal();
    }

    private boolean checkRow() {
        int n = 0;
        for (int i = 0; i < TicTacToe.size; i++) {
            if (TicTacToe.map[lastTurnRow][i] == playerSymbol) {
                n++;
                if (n == winLength) {
                    return true;
                }
            } else {
                n = 0;
            }
        }
        return false;
    }

    private boolean checkColumn() {
        int n = 0;
        for (int i = 0; i < TicTacToe.size; i++) {
            if (TicTacToe.map[i][lastTurnColumn] == playerSymbol) {
                n++;
                if (n == winLength) {
                    return true;
                }
            } else {
                n = 0;
            }
        }
        return false;
    }

    private boolean checkMainDiagonal() {
        int n = 0;
        int startRowIndex = (lastTurnRow > lastTurnColumn) ? lastTurnRow - lastTurnColumn : 0;
        int startColumnIndex = (lastTurnRow > lastTurnColumn) ? 0 : lastTurnColumn - lastTurnRow;

        for (int i = 0; i < TicTacToe.size; i++) {
            int row = startRowIndex + i;
            int column = startColumnIndex + i;
            if (row <= maxIndex && column <= maxIndex) {
                if (TicTacToe.map[row][column] == playerSymbol) {
                    n++;
                    if (n == winLength) {
                        return true;
                    }
                } else {
                    n = 0;
                }
            }
        }
        return false;
    }

    private boolean checkSideDiagonal() {
        int n = 0;
        int startRowIndex = Math.min((lastTurnRow + lastTurnColumn), maxIndex);
        int startColumnIndex = (startRowIndex == maxIndex) ? lastTurnRow + lastTurnColumn - startRowIndex : 0;

        for (int i = 0; i < TicTacToe.size; i++) {
            int row = startRowIndex - i;
            int column = startColumnIndex + i;
            if (row >= 0 && column <= maxIndex) {
                if (TicTacToe.map[row][column] == playerSymbol) {
                    n++;
                    if (n == winLength) {
                        return true;
                    }
                } else {
                    n = 0;
                }
            }
        }
        return false;
    }

    public void setLastTurnRow(int lastTurnRow) {
        this.lastTurnRow = lastTurnRow;
    }

    public void setLastTurnColumn(int lastTurnColumn) {
        this.lastTurnColumn = lastTurnColumn;
    }

    public void setMaxIndex(int maxIndex) {
        this.maxIndex = maxIndex;
    }
}
