package lesson5.am.dir2;

import lesson5.am.dir1.CatNew;

public class CatNewNew extends CatNew {

    public static void main(String[] args) {
        CatNewNew catNewNew = new CatNewNew();
    }

}
