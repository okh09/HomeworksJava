package lesson7.string;

import java.io.IOException;

public class StringConcat {

    public static void main(String[] args) {
        String a1 = "Hello My ";
        String a2 = "Dear World";
        String a3 = a1 + a2;
//        a3 = a1.concat(a2);


        String b1 = "Число";
        int b2 = 10;
        String b3 = b1 + b2;
//        b3 = b1.concat(String.valueOf(b2));

        String c = "(" + 2 + 3 + ")" + b3 + "!";

        System.out.println(a1.equalsIgnoreCase(a2));
        System.out.println(a1.compareTo(a2));

        String spaces = "      \t\n      ";
//        System.out.println(spaces.trim());
        System.out.println(spaces == null); //"" - false
        System.out.println(spaces.isEmpty()); //"" - true, " " - false
        System.out.println(spaces.isBlank()); //" " - true
        System.out.println(spaces.trim().isEmpty());

        System.out.println(a3.substring(10));
        System.out.println(a3.substring(10, 16));

        for (String s : a3.split("\s+", 3)) {
            System.out.println("Слово: " + s);
        }

        System.out.println(a3.charAt(10));
        System.out.println(a3.indexOf("e", 2));

        System.out.println(a3.replaceAll("My", "Our"));
        System.out.println(a3.repeat(2));

        String str = "/msg name текст данного сообщения...";
        System.out.println(a3.startsWith("/msg "));

        if (str.startsWith("/msg ")) {
            String[] strArray = str.split("\s+", 3);
            System.out.println("Пользователь: " + strArray[1]);
            System.out.println("Текст сообщения: " + strArray[2]);
        }

        String string = "worD";
        System.out.println(string.substring(0, 1).toUpperCase() + string.substring(1).toLowerCase());

        System.out.println(a3.toUpperCase());

    }

    private static String message(boolean b) {
        return "Your char had".concat(b ? " " : "n't ").concat("been found!");
    }
}
