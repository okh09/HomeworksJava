package lesson1;

import java.util.concurrent.ThreadLocalRandom;

public class Main {

    public static void main(String... args) {
//        printHelloWorld();
/*        printHelloWorld();
        printHelloWorld();*/

//        testVars();
//        checkAppraisal();

        testChecksAppraisal();

    }


    //UpperCamelCase
    //lowerCamelCase
    static void printHelloWorld() {
        System.out.println("Hello, world!");
    }

    //ctrl+alt+L
    private static void testVars() {
        int varA = 9;
        int varB = 5;
        int result = varA / varB;
        long longA = 10000000000L;
        System.out.println(varA / varB);

        double doubleVarA = 9; //(double)9
        float floatVar = 3.9f;

        double resultD = varA / varB;
        resultD = 1.0 * varA / varB;
        resultD = (double) varA / varB;
        System.out.println(resultD);

//        result = result + 10;
        result += 10;
        System.out.println(result);

        boolean isChange = false;

        char ch1 = 1234;
        char ch2 = '☺';
        System.out.println(ch1);
        System.out.println(ch2);

        String helloStr = "hello";
        String worldStr = "world";
        System.out.println(helloStr + ", " + worldStr);
        System.out.println(helloStr + ", " + worldStr + 5 + 6);
        System.out.println(helloStr + ", " + worldStr + (5 + 6) + true);

        int c = 0;
        c = c + 1;
        c += 1;
        c++;
        ++c;
        --c;
        c--;

    }

    private static void checkAppraisal() {
        int appraisal = ThreadLocalRandom.current().nextInt(8) - 2;
        System.out.println("Студент принес оценку: " + appraisal);

        if (appraisal == 5) {
            System.out.println("Молодец! Так держать!");
        } else if (appraisal == 4) {
            System.out.println("Хорошо, но ты можешь лучше");
//        } else if (appraisal == 3 || appraisal == 2 || appraisal == 1) {
        } else if (appraisal >= 1 && appraisal <= 3) {
            System.out.println("Готовь уроки лучше!");
        } else /*if (appraisal > 5 || appraisal < 1)*/ {
            System.out.println("Не мухлюй! Говори правду!");
        }

        System.out.println("Проверка окончена");
    }

    private static void testChecksAppraisal() {
        checkAppraisalWithArg(5);
        checkAppraisalWithArg(4);
        checkAppraisalWithArg(3);
        checkAppraisalWithArg(2);
        checkAppraisalWithArg(1);
        checkAppraisalWithArg(-1);
        checkAppraisalWithArg(6);
    }

    private static void checkAppraisalWithArg(int appraisal) {
        System.out.println("Студент принес оценку: " + appraisal);

        if (appraisal == 5) {
            System.out.println("Молодец! Так держать!");
        } else if (appraisal == 4) {
            System.out.println("Хорошо, но ты можешь лучше");
//        } else if (appraisal == 3 || appraisal == 2 || appraisal == 1) {
        } else if (appraisal >= 1 && appraisal <= 3) {
            System.out.println("Готовь уроки лучше!");
        } else /*if (appraisal > 5 || appraisal < 1)*/ {
            System.out.println("Не мухлюй! Говори правду!");
        }

        System.out.println("Проверка окончена");
    }
}
