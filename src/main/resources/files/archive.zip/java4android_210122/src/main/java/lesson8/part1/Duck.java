package lesson8.part1;

public class Duck extends Animal implements Runner, Swimming, Flying{


    @Override
    public void fly() {

    }

    @Override
    public void run() {

    }

    @Override
    public void action() {

    }

    @Override
    public void swim() {

    }
}
