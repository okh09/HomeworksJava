package lesson8.part1;

public class Animal {

}
