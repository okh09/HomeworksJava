package lesson8.part1;

public interface Swimming {
    void swim();
}
