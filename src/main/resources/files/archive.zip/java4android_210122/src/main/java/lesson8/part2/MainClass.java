package lesson8.part2;

public class MainClass {
    public void action() {
        System.out.println("!!!!!!!!!!!!");
    }

    public void action2() {
        System.out.println("!!!!!!!!!!!!");
    }

    public void action3() {
        System.out.println("!!!!!!!!!!!!");
    }

    public void action4() {
        System.out.println("!!!!!!!!!!!!");
    }

    public void act5ion() {
        System.out.println("!!!!!!!!!!!!");
    }

    public void act7ion() {
        System.out.println("!!!!!!!!!!!!");
    }
}
