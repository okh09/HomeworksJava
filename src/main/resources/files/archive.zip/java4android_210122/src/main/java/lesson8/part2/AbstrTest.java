package lesson8.part2;

public abstract class AbstrTest {
    public abstract void action();
}
