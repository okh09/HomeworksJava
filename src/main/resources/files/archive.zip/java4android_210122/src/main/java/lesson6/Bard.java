package lesson6;

public class Bard extends Player{
    public Bard(String nickname, int points) {
        super(nickname, points, "Бард");
    }

    @Override
    public void action() {
        System.out.println( getNickname() + " настраивает лютню");
    }

    public void sing() {
        System.out.println("ЗНАЕШЬ ЛИ ТЫЫЫЫЫЫЫЫЫЫЫЫЫЫ....");
    }
}
